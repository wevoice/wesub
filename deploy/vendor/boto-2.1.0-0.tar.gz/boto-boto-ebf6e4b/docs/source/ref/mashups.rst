.. ref-mashups

=======
mashups
=======

boto.mashups
------------

.. automodule:: boto.mashups
   :members:   
   :undoc-members:

boto.mashups.interactive
------------------------

.. automodule:: boto.mashups.interactive
   :members:   
   :undoc-members:

boto.mashups.iobject
--------------------

.. automodule:: boto.mashups.iobject
   :members:   
   :undoc-members:

boto.mashups.order
------------------

.. automodule:: boto.mashups.order
   :members:   
   :undoc-members:

boto.mashups.server
-------------------

.. automodule:: boto.mashups.server
   :members:   
   :undoc-members:

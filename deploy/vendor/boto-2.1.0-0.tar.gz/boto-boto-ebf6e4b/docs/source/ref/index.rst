.. _ref-index:

=============
API Reference
=============

.. toctree::
   :maxdepth: 4

   boto
   cloudfront
   contrib
   ec2
   ecs
   emr
   file
   fps
   gs
   iam
   manage
   mashups
   mturk
   pyami
   rds
   route53 
   s3
   sdb
   services
   ses
   sns
   sqs
   sts
   vpc
 

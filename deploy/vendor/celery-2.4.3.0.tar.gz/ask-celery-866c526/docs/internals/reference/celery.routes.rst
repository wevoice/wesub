=================================
 celery.routes
=================================

.. contents::
    :local:
.. currentmodule:: celery.routes

.. automodule:: celery.routes
    :members:
    :undoc-members:
